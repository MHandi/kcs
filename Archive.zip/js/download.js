/**
 * Created by Yujie on 21/11/14.
 */
$('#document').ready(function(){

    function voucher_1(){
        href="src/voucher/qrcode_258.jgp"
    }



});